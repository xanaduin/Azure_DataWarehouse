﻿CREATE SCHEMA [SCHEMA_A]
    AUTHORIZATION [dbo];







