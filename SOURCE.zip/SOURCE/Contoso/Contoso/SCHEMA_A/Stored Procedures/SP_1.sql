﻿CREATE PROC [SCHEMA_A].[SP_1] @Column1 [int],@Column2 [int],@Column3 [varchar](10) AS 
BEGIN 
 SET NOCOUNT ON; 
	BEGIN 
		insert into SCHEMA_A.TABLE_1 (Column1, Column2, Column3)
		values(@Column1, @Column2, @Column3)

	END 
END