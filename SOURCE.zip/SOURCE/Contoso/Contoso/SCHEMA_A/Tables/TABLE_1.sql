﻿CREATE TABLE [SCHEMA_A].[TABLE_1] (
    [Column1] INT          NOT NULL,
    [Column2] INT          NULL,
    [Column3] VARCHAR (10) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Column1]));

